<template>
   <header class="header" id="header-top">
      <div class="container">
         <nav class="navbar navbar-expand-sm fixed-top navbar-light bg-black mb-5">
               <div class="container">
               <a class="navbar-brand text-white h1 logotipo" href="#">
                  <img src="" alt="Unitec Bpartner">
               </a>
               <button class="navbar-toggler bg-transparent ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
               <span class="navbar-toggler-icon"></span>
               </button>
               <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <ul class="navbar-nav ml-auto "> 
                     <li class="nav-item">
                           <a class="nav-link text-white" href="#header-top">Inicio</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link text-white" href="#about">Sobre nós</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link text-white" href="#service">Serviços</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link text-white" href="#foot">Contactos</a>
                        </li>
                        <li class="nav-item">
                           <router-link to="/">Home</router-link>
                        </li>
                        <li class="nav-item">
                           <router-link to="/login">Login</router-link>
                        </li>
                     </ul>                       
                  </div>
               </div>
            </nav>
         <div class="header-content">
               <h3 class="text-right ml-auto smalltext">
                  Fundada por Jovens Moçambicanos com expertise em negócios, buscamos o melhor resultado para o nosso cliente com o que há de mais inovador e eficiente no mercado.
               </h3>
         </div>
      </div>
   </header>
</template>
  
<script>
export default {
   name: 'HeaderInc',
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
  