<template>
    <footer class="container-fluid bg-black py-5" id="foot">
        <div class="container">
           <div class="row">
              <div class="col-md-12">
                <div class="row">
                    <div class="col-md-12">
                        <h4 class="text-coruni hh">Entre em contacto connosco</h4>
                    </div>
                </div>
                 <div class="row">
                    <div class="col-md-6">
                       <ul class="footer2--list">
                        <li class="footer2--item py-1">
                          <a class="footer--link "><img src="../../../public/dist/img/phone.svg" alt=""> <a href="tel:+258840111248" class="footer--link">841088884</a> | <a
                              href="tel:+258840111428" class="footer--link">840111428</a> |
                            <a href="tel:+258870088688" class="footer--link">870088688</a> </a>
                        </li>
                        <li class="footer2--item py-1">
                          <a href="mailto:info@unitec.ac.mz" class="footer--link"><img src="../../../public/dist/img/email.svg" alt="">
                            info@unitec.ac.mz</a>
                        </li>
                        <li class="footer2--item py-1">
                            <a class="footer--link" href="https://goo.gl/maps/Xkj7sheyf3Wb9iJw6" target="_blank"><img
                                src="../../../public/dist/img/marker2.svg" alt=""> Av. Salvador Allende Nr.60, Maputo</a>
                          </li>
                        <li class="footer2--item py-1">
                            <a href="https://wa.me/+258841088884" target="_blank" class="btn btn-sm btn-light w-50">Fale connosco 
                                <!-- <img src="../../../dist/dist/img/icons8-whatsapp.svg" alt=""> -->
                                <i class="fa fa-whatsapp"></i>
                            </a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-3">
                        <ul class="footer--list py-1">
                            <li class="footer--item">
                                <a href="https://www.facebook.com/unitec.academy/" target="_blank" class="footer--link"> <img
                                    src="../../../public/dist/img/social-1.svg" alt=""> Facebook</a>
                            </li>
                            <li class="footer--item py-1">
                                <a href="https://twitter.com/OnlineUnitec" target="_blank" class="footer--link"> 
                                    <img src="../../../public/dist/img/social-2.svg" alt=""> Twitter</a>
                            </li>
                            <li class="footer--item py-1">
                                <a href="https://www.instagram.com/unitec.academy/" target="_blank" class="footer--link"> 
                                    <img src="../../../public/dist/img/social-3.svg" alt=""> Instagram</a>
                            </li>
                            <li class="footer--item py-1">
                                <a href="https://mz.linkedin.com/company/unitec-academy" target="_blank" class="footer--link"> 
                                <img src="../../../public/dist/img/linkedin.svg" alt=""> LinkedIn</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-3">
                        <div class="logo-part v-align-center">
                            <a href="https://unitec.ac.mz" class="footer--link text-white py-2">
                                <div class="footer2--logo">
                                    <img src="../../../public/dist/img/unitec.png" class="py-1" alt="">
                                    <img src="../../../public/dist/img/uniconnect.png" class="unispace" alt="">
                                </div>
                            </a>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <div class="section contact" id="contact">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1793.403269465809!2d32.58136134695703!3d-25.974384439187407!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1ee69ba452f58b8b%3A0xdfdd3e6f52050149!2sUniconnect%20Works!5e0!3m2!1spt-PT!2smz!4v1665068892800!5m2!1spt-PT!2smz" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
</template>

<script>
    export default {
        name: 'FooterSegInc',
    }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>