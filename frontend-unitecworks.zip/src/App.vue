<template>
  <header-inc></header-inc>

  <router-view/>

  <footer-inc></footer-inc>
</template>

<script>
import HeaderInc from '@/components/includes/HeaderInc.vue'
import FooterInc from '@/components/includes/FooterInc.vue'

export default {
//   name: 'HomePage',
  components: {
    HeaderInc,
    FooterInc,
  },
}

</script>


<style>

</style>
